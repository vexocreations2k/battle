TANK BATTLE - play with friends, each on their own phone

1. Send this zip to your friends (WhatsApp works). Everyone extracts it first.
2. Everyone opens index.html in Chrome. Internet is needed.
3. One person taps "Host a game for friends" and reads out the 4 letter room code.
4. Everyone else types that code and taps "Join a friend's game".

Tips: it works best when all phones use the same Wi-Fi or one phone's hotspot.
The host must keep the game open. If the host leaves, everyone else is disconnected.
Controls: stick on the left to drive, FIRE on the right. First to 10 knockouts wins.
